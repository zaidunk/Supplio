# maroon-fintech-landing — source code

Live demo: https://kedhar-components.pages.dev/#maroon-fintech-landing

Folders under components/ are React + TypeScript + Tailwind components.
Main file: components/maroon-fintech-landing/maroon-fintech-landing.tsx  (usage example: components/maroon-fintech-landing/demo.tsx)

Put each folder's .tsx file at src/components/ui/<folder>.tsx in a
shadcn-style project (the code imports siblings as @/components/ui/<name>).

npm packages used: react

License: MIT. Author: Kedhareswer Naidu (https://kedhar.pages.dev).
